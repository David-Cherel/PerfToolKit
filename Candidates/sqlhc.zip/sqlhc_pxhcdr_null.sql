Rem
Rem $Header: sqlhc_pxhcdr_null.sql 06-mar-2024.22:36:10 $
Rem
Rem sqlhc_pxhcdr_null.sql
Rem
Rem Copyright (c) 2024, Oracle and/or its affiliates.
Rem
Rem    NAME
Rem      sqlhc_pxhcdr_null.sql - No PX lines
Rem
Rem    DESCRIPTION
Rem
Rem    NOTES
Rem
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    smuthuku    03/06/24 - SQLHC version update ER 36374176 
Rem    scharala    12/24/23 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql
prompt No Parallel element detected or unimplemented platform. 
@?/rdbms/admin/sqlsessend.sql
