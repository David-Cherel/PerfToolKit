#!/usr/bin/python

"""
    Real-World Performance

    @author:        Ivica Arsov (ivica.arsov@oracle.com)
    @last_updated:  02.09.2024
    @Purpose:       Simple tool to measure network latency
                        - Client elapsed time
                        - Database elapsed time
                        - Network time

    iarsov  26.02.2024  add option to run python-oracledb in thin-mode
    iarsov  02.09.2024  switch to python-oracledb
                        add "ping" measurement
    iarsov  01.09.2022  added command_type filter for DB time from V$SQLAREA
    iarsov  28.06.2022  fixed bug with wrong Network time (execution)
    iarsov  24.06.2022  fixed bug with wrong DB time reported
    iarsov  17.06.2022  categorize network time
    iarsov  06.05.2022  added description for client elapsed time
    iarsov  02.03.2022  added option end-user to run custom query
    iarsov  11.02.2022  fixed import of cx_Oracle if preinstalled lib. exist
    iarsov  10.12.2021  added JSON support for results print
"""

from __future__ import print_function
from __future__ import division

import sys
import traceback
import platform
import json

if platform.architecture()[0] == "64bit":
    
    if platform.system() == "Linux":
        sys.path.insert(0, "./lib_linux/{}/p{}{}".format(platform.processor(),
                                                         sys.version_info[0],
                                                         sys.version_info[1]))

    elif platform.system() == "Windows":
        l_lib_dir = "lib_win"
        sys.path.insert(0, "./lib_win/p{}{}".format(sys.version_info[0],
                                                    sys.version_info[1]))
    else:
        print("Unsupported platform!")    
else:
    print("Unsupported architecture!")


# start: import libraries
import os
import datetime

try:
    import warnings
    warnings.filterwarnings(action='ignore', module='oracledb')
    import oracledb
    # initialize oracledb
except ImportError:
    print()
    print("could not load oracledb module!")
    print("make sure oracledb libraries are extracted.\n")
    sys.exit()

from timeit import default_timer as timer
import time
import getopt
import statistics
import signal
import random
import getpass
# end: import libraries

g_version = "2.2"

# start: define activity color
SCGR  = '\033[42m'
SFBOLD = '\033[1m'
SFITALIC = '\033[3m'
SFEND  = '\033[0m'
# end: define activity color

# start: define variables
g_user = None
g_user_password = None
g_service = None
g_type = None
g_fetchsize = 100 #default
g_iterations = 0
g_iterDWH = 100 # default
g_iterOLTP = 10000 # default
g_connection = None
g_total_db_ela = 0
g_total_ela = 0
g_fetch_calls = 0
g_sql = None
g_sqlId = None
g_bytes_sent = 0
g_10046 = False
g_custom_script = None
g_trc_path = None
g_json_output = False

g_fetch_ela = 0
g_fetch_ela_min = 0
g_fetch_ela_max = 0
g_fetch_ela_max_skip_first = 0
g_adb_pod = None
g_adb_dbname = None
g_adb_region = None
g_debug = False
g_thin_mode = False
g_numrows = 0
g_ping_interval = 1
g_ping_period = 10

# network ela
g_nexec_ela = 0
# network end-of-fetch
g_neof_ela = 0

# round trips from DB to client
g_rtrps = 0

# g_script_start  = timer()
# end: define variables

# start: function definition

g_uniqidentifier = datetime.datetime.now().strftime("%Y%d%H%M%S%f")

def processArgv():

    global g_type
    global g_iterations
    global g_fetchsize
    global g_numrows
    global g_user
    global g_user_password
    global g_service
    global g_10046
    global g_custom_script
    global g_debug
    global g_json_output
    global g_ping_interval
    global g_ping_period
    global g_thin_mode

    try:
        l_argv = sys.argv[1:]
        opts, args = getopt.getopt(l_argv
                                   ,"hf:t:e:u:s:n:p:wc:dc:j"
                                   , ["ping-interval="
                                       , "ping-period="
                                       , "oracledb-thin-mode"])

        for opt, arg in opts:
            if opt == '-h':
                printUsage()
            elif opt in ("-u"):
                g_user = arg
            elif opt in ("-p"):
                g_user_password = arg
            elif opt in ("-s"):
                g_service = arg
            elif opt in ("-f"):
                g_fetchsize = int(arg)
            elif opt in ("-w"):
                g_10046 = True
            elif opt in ("-n"):
                g_numrows = int(arg)
            elif opt in ("-c"):
                g_custom_script = arg.lower()
            elif opt in ("-t"):
                g_type = arg.lower()
            elif opt in ("-e"):
                g_iterations = int(arg)
            elif opt in ("-d"):
                g_debug = True
            elif opt in ("-j"):
                g_json_output = True
            elif opt in ("--ping-interval"):
                g_ping_interval = int(arg)
            elif opt in ("--ping-period"):
                g_ping_period = int(arg)
            elif opt in ("--oracledb-thin-mode"):
                g_thin_mode = True
            else:
                printUsage()

        if g_user is None or g_service is None or g_type is None or g_numrows is None:
            printUsage()

        if g_type not in ("dwh", "oltp", "ping") and g_custom_script is None:
            printUsage()
        if g_custom_script is not None and g_type != 'user':
            printUsage()

    except SystemExit:
        sys.exit()
    except:
        printUsage()

def getPassword():

    # before password input register CTRL+C event to func signal_handlerOnPasswordInput
    # this will exit if user press CTLR+C
    signal.signal(signal.SIGINT, signalHandlerOnPasswordInput)
    global g_user_password
    g_user_password = getpass.getpass(prompt='Enter password for {0}: '.format(g_user.upper()), stream=None)


    # after user provides password, register CTRL+C to func signal_handler
    # this will print summary after CTRl+C
    signal.signal(signal.SIGINT, signalHandler)


def printOut(p_text="", p_end="", p_error = False):

    if not g_json_output or p_error:
        print(p_text, p_end)

def printHeader():

    printOut()
    l_wrapper_length = 45

    printOut("-" * l_wrapper_length)
    l_string =  """
\tReal-World Performance

 Simple tool to measure network latency v{0}

 - Client elapsed time
 - Database elapsed time
 - Network time
""".format(g_version)
    printOut(l_string)
    printOut("-" * l_wrapper_length)
    printOut()

def printUsage():
    printOut()
    printOut("Usage:")
    printOut("dbrwplt.py -u <user> -p <password> -s <service name> -t <dwh|oltp|user|ping> -e <number of executions> -f <fetch array size> -n <number of rows to fetch> -c <file> -w <enable 10046 trace>\n")
    printOut("""Arguments:
-u [mandatory]: Username to connect to the DB.
-p [optional] : User password. Useful for scripting.
-s [mandatory]: Service name to use for DB connection.
-t [mandatory]: Type of run, can be DWH, OLTP, USER or PING.
-n [mandatory]: Number of rows to fetch.
-e [optional] : Number of executions. 
                For OLTP default is 10,000
                For DWH default is 100
-f [optional]:  Fetch array size. Default value is 100.
-c [optional]:  File containing query to execute. Only applicable with "-t USER".
-w [optional]:  Enable 10046 trace.
--ping-interval [optional]: Ping interval. Default is 1 second.
--ping-period   [optional]: How long the program should run. Default is 10 seconds.
""")
    #-c [optional]:  User defined query statement (SQL script) to be executed. Applicable only with combination "-t user".
    #-t <dwh|oltp|user>
    #-t [mandatory]: Type of run, can be DWH or OLTP or USER.

    # printOut("Default values:")
    # printOut("-"*18)
    # printOut("""Number of executions:
    # - DWH: {0:,}
    # - OLTP: {1:,}""".format(g_iterDWH, g_iterOLTP))
    # printOut("Fetch size: {0:,}".format(g_fetchsize))
    # printOut("-"*18)
    printOut("""Note:\tIf you are connecting to Oracle Cloud Autonomous Database set TNS_ADMIN to your wallet location.
\tMake sure wallet location is properly configured in sqlnet.ora""")
    printOut()
    printOut("Example run: ./dbrwplt.py -u admin -s iarsovdb_low -t dwh -n 10000")
    printOut()
    sys.exit()

def signalHandler(sig, frame):
    printOut()
    printOut()
    printOut("You have pressed Ctrl+C!")

def signalHandlerOnPasswordInput(sig, frame):
    printOut()
    printOut()
    printOut("You have pressed Ctrl+C!")
    sys.exit()

# Print iterations progress
def printActivityBar (iteration, total):
    l_length = 50
    percent = ("{0:.1f}").format(100 * (iteration / float(total)))
    # filledLength = int(l_length * iteration // total)
    print("\r Progress {0} % completed".format(percent), end = "\r")
    sys.stdout.flush()

    # on complete print new line
    if iteration == total:
        printOut()

def exitProgram():
    printOut()
    sys.exit()

def preCheck():

    if "TNS_ADMIN" not in os.environ:
        printOut("OS environment variable TNS_ADMIN is not set.")
        printOut("Please set TNS_ADMIN")
        exitProgram()
    else:
        printOut("Execution date: {0}".format(datetime.datetime.now().strftime("%A %d, %b %Y %H:%M:%S")))
        printOut("TNS_ADMIN is set to: [{0}]\n".format(os.environ['TNS_ADMIN']))

def connectDB():

    global g_connection
    try:
        g_connection = oracledb.connect(user=g_user, password=g_user_password, dsn=g_service)
        l_oracledb_mode: str = "thick mode"

        if g_thin_mode:
            l_oracledb_mode = "thin mode"

        printOut("1. Connection successfully established ({})".format(l_oracledb_mode))
    except:
        printOut("Failed to establish connection!", p_error=True)
        printOut("error: [{0}]".format(sys.exc_info()[1]), p_error=True)
        exitProgram()

def prepareProgram():

    printOut("2. Prepare to execute {0}".format(g_type.upper()))

    global g_iterations
    global g_sql

    if g_type == "dwh":
        g_iterations = g_iterDWH if g_iterations == 0 else g_iterations
        g_sql = """with data_s as (select dbms_random.string('a',30000) col1, to_char(sysdate,'dd.mm.yyyy hh24:mi:ss') col2, to_char(systimestamp) col3 from dual)
                            select /*dbrwplt-{0}*/ /*+ no_parallel */
                                ROWNUM, (select col1 from data_s) col1a , (select col1 from data_s) col2a
                                , (select col1 from data_s) col3a , (select col2 from data_s) col4a
                                , (select col1 from data_s) col5a , (select col3 from data_s) col6a
                                , (select col1 from data_s) col7a , ROWNUM col8a
                                , (select col1 from data_s) col9a , (select col1 from data_s) col10b
                                , (select col1 from data_s) col1b , (select col1 from data_s) col2b
                                , (select col1 from data_s) col3b , (select col2 from data_s) col4b
                                , (select col1 from data_s) col5b , (select col3 from data_s) col6b
                                , (select col1 from data_s) col7b , ROWNUM col8b
                                , (select col1 from data_s) col9b , (select col1 from data_s) col10c
                                , (select col1 from data_s) col1c , (select col1 from data_s) col2c
                                , (select col1 from data_s) col3c , (select col2 from data_s) col4c
                                , (select col1 from data_s) col5c , (select col3 from data_s) col6c
                                , (select col1 from data_s) col7c , ROWNUM col8c
                                , (select col1 from data_s) col9c , (select col1 from data_s) col10d
                                , (select col1 from data_s) col1d , (select col1 from data_s) col2d
                                , (select col1 from data_s) col3d , (select col2 from data_s) col4d
                                , (select col1 from data_s) col5d , (select col3 from data_s) col6d
                                , (select col1 from data_s) col7d , ROWNUM col8d
                                , (select col1 from data_s) col9d , (select col1 from data_s) col10d
                                , (select col1 from data_s) col1e , (select col1 from data_s) col2e
                                , (select col1 from data_s) col3e , (select col2 from data_s) col4e
                                , (select col1 from data_s) col5e , (select col3 from data_s) col6e
                                , (select col1 from data_s) col7e , ROWNUM col8e
                                , (select col1 from data_s) col9e , (select col1 from data_s) col10f
                                , (select col1 from data_s) col1f , (select col1 from data_s) col2f
                                , (select col1 from data_s) col3f , (select col2 from data_s) col4f
                                , (select col1 from data_s) col5f , (select col3 from data_s) col6f
                                , (select col1 from data_s) col7f , ROWNUM col8f
                                , (select col1 from data_s) col9f , (select col1 from data_s) col10f
                            from xmltable('1 to {1}')""".format(g_uniqidentifier, g_numrows)
        # g_sql = """with data_s as (select dbms_random.string('a',30000) col1, to_char(sysdate,'dd.mm.yyyy hh24:mi:ss') col2, to_char(systimestamp) col3 from dual)
        #             select /*dbrwplt-{0}*/ /*+ no_parallel */
        #                 (select col1 from data_s) col1a , (select col1 from data_s) col2a
        #                 , rownum||(select col1 from data_s) col3a , rownum||(select col2 from data_s) col4a
        #                 , rownum||(select col1 from data_s) col5a , rownum||(select col3 from data_s) col6a
        #                 , rownum||(select col1 from data_s) col7a , ROWNUM col8a
        #                 , rownum||(select col1 from data_s) col9a , rownum||(select col1 from data_s) col10b
        #                 , rownum||(select col1 from data_s) col1b , rownum||(select col1 from data_s) col2b
        #                 , rownum||(select col1 from data_s) col3b , rownum||(select col2 from data_s) col4b
        #                 , rownum||(select col1 from data_s) col5b , rownum||(select col3 from data_s) col6b
        #                 , rownum||(select col1 from data_s) col7b , ROWNUM col8b
        #                 , rownum||(select col1 from data_s) col9b , rownum||(select col1 from data_s) col10c
        #                 , rownum||(select col1 from data_s) col1c , rownum||(select col1 from data_s) col2c
        #                 , rownum||(select col1 from data_s) col3c , rownum||(select col2 from data_s) col4c
        #                 , rownum||(select col1 from data_s) col5c , rownum||(select col3 from data_s) col6c
        #                 , rownum||(select col1 from data_s) col7c , ROWNUM col8c
        #                 , rownum||(select col1 from data_s) col9c , rownum||(select col1 from data_s) col10d
        #                 , rownum||(select col1 from data_s) col1d , rownum||(select col1 from data_s) col2d
        #                 , rownum||(select col1 from data_s) col3d , rownum||(select col2 from data_s) col4d
        #                 , rownum||(select col1 from data_s) col5d , rownum||(select col3 from data_s) col6d
        #                 , rownum||(select col1 from data_s) col7d , ROWNUM col8d
        #                 , rownum||(select col1 from data_s) col9d , rownum||(select col1 from data_s) col10d
        #                 , rownum||(select col1 from data_s) col1e , rownum||(select col1 from data_s) col2e
        #                 , rownum||(select col1 from data_s) col3e , rownum||(select col2 from data_s) col4e
        #                 , rownum||(select col1 from data_s) col5e , rownum||(select col3 from data_s) col6e
        #                 , rownum||(select col1 from data_s) col7e , ROWNUM col8e
        #                 , rownum||(select col1 from data_s) col9e , rownum||(select col1 from data_s) col10f
        #                 , rownum||(select col1 from data_s) col1f , rownum||(select col1 from data_s) col2f
        #                 , rownum||(select col1 from data_s) col3f , rownum||(select col2 from data_s) col4f
        #                 , rownum||(select col1 from data_s) col5f , rownum||(select col3 from data_s) col6f
        #                 , rownum||(select col1 from data_s) col7f , ROWNUM col8f
        #                 , rownum||(select col1 from data_s) col9f , rownum||(select col1 from data_s) col10f
        #             from xmltable('1 to {1}')""".format(g_uniqidentifier, g_numrows)
    elif g_type == "oltp":
        g_iterations = g_iterOLTP if g_iterations == 0 else g_iterations
        # g_sql = """with data_s as (select dbms_random.string('a',30) col1, sysdate col2, systimestamp col3 from dual)
        #             select /*dbrwplt-{0}*/ /*+ no_parallel */
        #                 (select col1 from data_s) col1
        #                 , (select col2 from data_s) col2
        #             from xmltable('1 to {1}')""".format(g_uniqidentifier, g_numrows)
        g_sql = """with data_s as (select dbms_random.string('a',30) col1, sysdate col2, systimestamp col3 from dual)
                    select /*dbrwplt-{0}*/ /*+ no_parallel */
                        rownum||(select col1 from data_s) col1
                        ,rownum||(select col2 from data_s) col2
                    from xmltable('1 to {1}')""".format(g_uniqidentifier, g_numrows)
        # g_sql = """with data_s as (select dbms_random.string('a',30) col1, to_char(sysdate,'dd.mm.yyyy') col2, systimestamp col3 from dual)
        #             select /*dbrwplt-{0}*/ /*+ no_parallel */
        #                 case when mod(rownum,2) = 0 then (select col1 from data_s) else (select col2 from data_s) end col1
        #                 ,case when mod(rownum,2) = 0 then (select col2 from data_s) else (select col1 from data_s) end col2
        #             from xmltable('1 to {1}')""".format(g_uniqidentifier, g_numrows)
        # g_sql = """with data_s as (select dbms_random.string('a',30) col1, to_char(sysdate,'dd.mm.yyyy') col2, systimestamp col3 from dual)
        #             select /*dbrwplt-{0}*/ /*+ no_parallel */
        #                 dbms_random.string('a',30) col1
        #                 ,sysdate + rownum col2
        #             from xmltable('1 to {1}')""".format(g_uniqidentifier, g_numrows)
    elif g_type == "user":
        try:
            f = open(g_custom_script,"r")
            g_sql = f.read()
        except:
            printOut("Failed to read user script [{}]".format(g_custom_script), p_error=True)
            exitProgram()
    elif g_type == "ping":
        pass
    else:
        printUsage()

    # check privileges if 10046 tracing is enabled
    if g_10046:
        l_cursor = g_connection.cursor()
        if g_adb_dbname and g_adb_region:
            l_cursor.execute("select count(1) from user_sys_privs where privilege = 'ALTER SESSION'")
            l_res = l_cursor.fetchone()
            if int(l_res[0]) == 0:
                printOut("Error: USER is missing ALTER SESSION privilege.", p_error=True)
                exitProgram()
        else:
            l_cursor.execute("select count(1) from user_tab_privs where table_name = 'DBMS_MONITOR' and privilege = 'EXECUTE'")
            l_res = l_cursor.fetchone()
            if int(l_res[0]) == 0:
                printOut("Error: USER is missing EXECUTE privilege on DBMS_MONITOR package.", p_error=True)
                exitProgram()
        l_cursor.close()


def oraping():

    try:

        oraping_samples = []
        t_end = time.time() + g_ping_period
        while time.time() < t_end:
            l_time_exec_start = timer()
            g_connection.ping()
            l_time_exec_end = timer()
            g_ping_ela = (l_time_exec_end - l_time_exec_start)
            oraping_samples.append(g_ping_ela)
            printOut("{0:,}".format(round(g_ping_ela*1000,3)).rjust(12) + " ms ; {}".format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")))
            time.sleep(g_ping_interval)
        printOut()

        printOut("ping (ms) mean={}, stddev={}, min={}, max={}".format(round(statistics.mean(oraping_samples)*1000,3),
                                                                       round(statistics.stdev(oraping_samples)*1000,3),
                                                                       round(min(oraping_samples)*1000,3),
                                                                       round(max(oraping_samples)*1000,3)))
        printOut()

    except:
            printOut("Oracle error message: [{0}]".format(sys.exc_info()[1]), p_error=True)
            pass


def executeProgram():

    printOut("3. Executing...\n")

    if g_type == "ping":
        oraping()
        return

    global g_total_ela
    global g_fetch_calls
    global g_fetch_ela_max
    global g_fetch_ela_max_skip_first
    global g_fetch_ela_min
    global g_fetch_ela
    global g_nexec_ela
    global g_neof_ela

    l_cursor = g_connection.cursor()

    try:
        l_cursor.execute("alter session set optimizer_ignore_hints=false")
        l_cursor.execute("alter session set optimizer_ignore_parallel_hints=false")
    except:
        pass

    if g_10046:
        if g_adb_dbname and g_adb_region:
            # check if DEFAULT_CREDENTIAL and DEFAULT_LOGGING_BUCKET are set
            l_cursor.execute("""select count(1) from database_properties 
where property_name in ('DEFAULT_CREDENTIAL','DEFAULT_LOGGING_BUCKET')
and property_value is not null""")
            l_res = l_cursor.fetchone()
            if int(l_res[0]) == 2:
                l_cursor.execute("begin DBMS_SESSION.SET_IDENTIFIER('{}'); end;".format(g_uniqidentifier))
                l_cursor.execute("alter session set sql_trace=true")
            else:
                printOut("Error: DEFAULT_CREDENTIAL and/or DEFAULT_LOGGING_BUCKET are not properly set.", p_error=True)
        else:
            l_cursor.execute("alter session set tracefile_identifier='{}'".format(g_uniqidentifier))
            l_cursor.execute("begin DBMS_MONITOR.session_trace_enable(waits=>TRUE, binds=>FALSE); end;")

    if oracledb.version.startswith("7"):
            printOut("")
            printOut("!Warning: oracledb pre-fetch could not be turned off due to oracledb version [{}]".format(oracledb.version))
            printOut("")
    else:
        l_cursor.prefetchrows = 0
        printOut("")
        printOut("!Note: oracledb pre-fetch has been disabled")
        printOut("")

    printActivityBar(0, g_iterations)

    try:

        l_rtrps_start = init_roundtrips()

        l_cursor.execute("begin DBMS_APPLICATION_INFO.SET_ACTION(:1); end;", ["dbrwplt-{}".format(g_uniqidentifier)])

        for l_exec in range(g_iterations):

            l_time_start = timer()

            l_cursor.arraysize = g_fetchsize

            l_time_exec_start = timer()
            l_cursor.execute(g_sql)
            l_time_exec_end = timer()
            # capture exec ela
            g_nexec_ela += (l_time_exec_end - l_time_exec_start)

            while True:
                l_delta_fetch = 0
                l_time_fetch_start = timer()
                result = l_cursor.fetchmany()
                l_time_fetch_end = timer()
                l_delta_fetch = (l_time_fetch_end - l_time_fetch_start)

                if len(result) == 0:
                    # capture end-of-fetch call
                    g_neof_ela += l_delta_fetch
                    break

                g_fetch_calls += 1

                if g_fetch_calls == 2:
                    # if we hit a second fetch
                    # reset the g_fetch_ela_max which will
                    # basically skip the first fetch for MAX fetch time.
                    g_fetch_ela_max_skip_first = 0

                if l_delta_fetch > g_fetch_ela_max:
                    g_fetch_ela_max = l_delta_fetch
                if l_delta_fetch > g_fetch_ela_max_skip_first:
                    g_fetch_ela_max_skip_first = l_delta_fetch

                if l_delta_fetch < g_fetch_ela_min or g_fetch_ela_min == 0:
                    g_fetch_ela_min = l_delta_fetch
                g_fetch_ela += l_delta_fetch

            l_time_end = timer()
            l_delta = (l_time_end - l_time_start)
            g_total_ela += l_delta

            printActivityBar(l_exec + 1, g_iterations)

        l_cursor.execute("begin DBMS_APPLICATION_INFO.SET_ACTION(NULL); end;")

        getSessInfo(l_rtrps_start)

        if g_10046:
            if g_adb_dbname and g_adb_region:
                l_cursor.execute("ALTER SESSION SET SQL_TRACE = FALSE")
            else:
                l_cursor.execute("begin DBMS_MONITOR.session_trace_disable; end;")

        l_cursor.close()

    except:
        printOut("Oracle error message: [{0}]".format(sys.exc_info()[1]), p_error=True)
        pass

def init_roundtrips():

    l_cursor = g_connection.cursor()
    # round-trips to client
    l_rtrps_sql = """select mst.value
    from v$statname sn, v$mystat mst
    where sn.statistic# = mst.statistic#
    and sn.name = 'SQL*Net roundtrips to/from client'"""
    l_cursor.execute(l_rtrps_sql)
    l_res = l_cursor.fetchone()[0]
    l_cursor.close()
    return l_res

def getSessInfo(p_init_roundtrips):

    global g_rtrps
    global g_bytes_sent

    l_cursor = g_connection.cursor()
    l_cursor.execute('''select value from (select case when t2.name = 'bytes sent via SQL*Net to client' then 1 else 2 end rnum, t1.value
    from v$sesstat t1, v$statname t2
    where t1.statistic# = t2.statistic#
    and t1.sid = sys_context('USERENV','SID')
    and t2.name in ('bytes sent via SQL*Net to client', 'SQL*Net roundtrips to/from client')
    ) order by rnum
    ''')

    result = l_cursor.fetchall()
    g_bytes_sent = (int(result[0][0]))
    l_rtrps_end = (int(result[1][0]))
    g_rtrps = (l_rtrps_end - p_init_roundtrips) - 2 # we have -2 to accommodate the setting/reset for ACTION
    l_cursor.close()


def getADBInfo():

    global g_adb_pod
    global g_adb_dbname
    global g_adb_region

    # get cursor elapsed time
    l_cursor = g_connection.cursor()
    try:
        l_cursor.execute("""select  json_value(cloud_identity,'$.DATABASE_NAME') db_name,
                                    json_value(cloud_identity,'$.REGION') region
                            from v$pdbs
                            where cloud_identity is not null""")
        result = l_cursor.fetchone()
        if result:
            g_adb_dbname = result[0]
            g_adb_region = result[1]
    except:
        # fail to detect CLOUD IDENTITY
        # ADB-D do not have CLOUD_IDENTITY column/ - TODO.
        # skip
        pass

    l_cursor.execute("""select name from v$database""")
    result = l_cursor.fetchone()
    if g_adb_region:
        g_adb_pod = result[0]
    else:
        # if region is not set we are not on ADB
        # set g_adb_dbname to DB name extracted from V$DATABASE
        g_adb_dbname = result[0]
    l_cursor.close()

def getDBEla():

    global g_total_db_ela
    global g_bytes_sent
    global g_trc_path
    global g_sqlId
    # get cursor elapsed time
    l_cursor = g_connection.cursor()

    l_cursor.execute("""select sql_id, elapsed_time
                        from v$sqlarea
                        where command_type = 3 and action = :1""", ["dbrwplt-{}".format(g_uniqidentifier)])

    result = l_cursor.fetchone()
    g_sqlId = result[0]
    g_total_db_ela = (int(result[1]) / 1000000)

    if g_10046:
        l_cursor.execute("""select p1.tracefile
                            from v$session s2, v$process p1
                            where s2.sid = sys_context('USERENV','SID')
                            and s2.paddr = p1.addr
                            """)
        result = l_cursor.fetchone()        
        g_trc_path = result[0]
        # TODO: trace file path for CLOUD - ADW ?
    
    l_cursor.close()

def printSummary():

    l_network_ela   = 0

    printOut()
    printOut(SFBOLD + "Results:" + SFEND)
    printOut("-" * 45)
    if g_adb_region:
        printOut("Region: {}".format(g_adb_region).rjust(12))
        printOut("POD: {}".format(g_adb_pod).rjust(12))
    printOut("Database: {}".format(g_adb_dbname).rjust(12))
    printOut()
    printOut("-" * 20)
    printOut("Number of executions\t\t:" + "{0:,}".format(g_iterations).rjust(12))
    printOut("Total fetch calls\t\t:" + "{0:,}".format(g_fetch_calls).rjust(12))
    printOut()

    printOut("SQL ID: {0}".format(g_sqlId))
    printOut("Bytes sent to client\t\t:" + " {0:,}".format(g_bytes_sent).rjust(12))
    printOut("Megabytes sent to client\t:" + " {0:,}".format(round(g_bytes_sent/1024/1024,2)).rjust(12))

    # Client time
    printOut("-" * 45)
    hours, rem = divmod(g_total_ela, 3600)
    minutes, seconds = divmod(rem, 60)
    printOut("Client elapsed time\t\t: {:0>2}:{:0>2}:{:05.2f}".format(int(hours),int(minutes),seconds))

    #DB Time
    hours, rem = divmod(g_total_db_ela, 3600)
    minutes, seconds = divmod(rem, 60)
    printOut("Database elapsed time\t\t: {:0>2}:{:0>2}:{:05.2f}".format(int(hours),int(minutes),seconds))

    # hours, rem = divmod((g_nexec_ela - g_total_db_ela), 3600)
    hours, rem = divmod(g_nexec_ela, 3600)
    minutes, seconds = divmod(rem, 60)
    printOut("\nExecution phase\n (network time + DB time)\t: {:0>2}:{:0>2}:{:05.2f}\n".format(int(hours), int(minutes), seconds))

    l_network_ela = g_fetch_ela  # (g_fetch_ela - g_total_db_ela)
    hours, rem = divmod(l_network_ela, 3600)
    minutes, seconds = divmod(rem, 60)
    printOut("Network time (data fetch)\t: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

    hours, rem = divmod(g_neof_ela, 3600)
    minutes, seconds = divmod(rem, 60)
    printOut("Network time (end-of-fetch)\t: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

    printOut("SQL*Net roundtrips\t\t:" + "{0:,}".format(g_rtrps).rjust(12) + " to/from client")

    printOut("-" * 45)
    l_network_ela_per_exec = l_network_ela/g_iterations
    printOut("Network time per execution\t:" + "{:01.4f}".format(l_network_ela_per_exec).rjust(12) + " s/execution")

    l_network_ela_per_fetch = l_network_ela/g_fetch_calls
    printOut("Network time per fetch call\t:" + "{:01.4f}".format(l_network_ela_per_fetch).rjust(12) + " s/fetch")
    printOut("\t\t\t\t " + "{0:,}".format(round(l_network_ela_per_fetch*1000,3)).rjust(12) + " ms/fetch/avg")
    printOut("\t\t\t\t " + "{0:,}".format(round(g_fetch_ela_max*1000,3)).rjust(12) + " ms/fetch/max")
    printOut("\t\t\t\t " + "{0:,}".format(round(g_fetch_ela_max_skip_first*1000,3)).rjust(12) + " ms/fetch/max (w/o first fetch)")
    printOut("\t\t\t\t " + "{0:,}".format(round(g_fetch_ela_min*1000,3)).rjust(12) + " ms/fetch/min")

    l_db_ela_per_exec = g_total_db_ela/g_iterations
    printOut("Database time per execution\t:" + "{:01.4f}".format(l_db_ela_per_exec).rjust(12) + " s/SQL")
    # printOut("Note: Script time represents the time to execute dbrwplt script (" + SFITALIC + "does not include the time needed to enter password" + SFEND + ")")
    # printOut()

    printOut("\n* Client elapsed time is inflated by additional\n"
             "round trips associated with {} executes\n"
             "and {} checks for end of fetch.\n".format(g_iterations,
                                                        g_iterations))

    if g_10046:
        printOut("-" * 45)
        printOut("10046 trace file: \"{}\"".format(g_trc_path))

    printOut()

def printJSON():

    l_json_dict = {}

    l_network_ela = g_fetch_ela
    hours, rem = divmod(l_network_ela, 3600)
    minutes, seconds = divmod(rem, 60)
    l_json_dict["Network time"] = "{:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds)

    l_network_ela_per_exec = l_network_ela / g_iterations
    l_json_dict["Network time per execution"] = "{:01.4f}".format(l_network_ela_per_exec)

    l_network_ela_per_fetch = l_network_ela / g_fetch_calls
    l_json_dict["Network time per fetch call"] = "{:01.4f}".format(l_network_ela_per_fetch)
    l_json_dict["ms/fetch/avg"] = "{0:,}".format(round(l_network_ela_per_fetch * 1000, 3))
    l_json_dict["ms/fetch/max"] = "{0:,}".format(round(g_fetch_ela_max * 1000, 3))
    l_json_dict["ms/fetch/max (w/o first fetch)"] = "{0:,}".format(round(g_fetch_ela_max_skip_first * 1000, 3))
    l_json_dict["ms/fetch/min"] = "{0:,}".format(round(g_fetch_ela_min * 1000, 3))

    l_db_ela_per_exec = g_total_db_ela / g_iterations
    l_json_dict["Database time per execution"] = "{:01.4f}".format(l_db_ela_per_exec)

    # Serializing json
    json_object = json.dumps(l_json_dict)
    print(json_object)
    sys.stdout.flush()


# start
try:
    processArgv()

    if not g_json_output:
        printHeader()

    if not g_user_password:
        getPassword()

    if g_debug:
        printOut("Debug mode enabled.")

    try:
        if not g_thin_mode:
            oracledb.init_oracle_client()
    except:
        print("\n!!!Could not enable python-oracledb Thick mode. Will run in Thin mode.")

    # preCheck()
    connectDB()
    prepareProgram()
    executeProgram()

    if g_type != "ping":

        getDBEla()
        getADBInfo()

        if g_json_output:
            printJSON()
        else:
            printSummary()

except SystemExit:
    pass

except:
    printOut("exit: something went wrong!")
    if g_debug:
        printOut(traceback.print_exc())
    sys.exit()
# end
