#!/bin/bash


CONNECT_STRING="/ as sysdba"
# Path to the Perl script
PERL_SCRIPT="perf_tool_kit.pl"

# Check if the ORACLE_HOME environment variable is set
if [ -z "$ORACLE_HOME" ]; then
  echo "ORACLE_HOME is not defined"
  exit 1
fi



# Check if the Perl script exists
if [ ! -f "$PERL_SCRIPT" ]; then
  echo "Perl script $PERL_SCRIPT does not exist."
  exit 1
fi

chmod +x $PERL_SCRIPT

# New shebang with ORACLE_HOME
NEW_SHEBANG="#!$ORACLE_HOME/perl/bin/perl"

# Update the shebang in the Perl script
sed -i "1s;^#!.*$;$NEW_SHEBANG;" "$PERL_SCRIPT"


# Function to check if the database is up
PMON_PROCESS=$(ps -ef | grep "ora_pmon_$ORACLE_SID" | grep -v "grep")

if [ -n "$PMON_PROCESS" ]; then
    echo "Oracle Database instance $ORACLE_SID is up (PMON process is running)."
    
else
    echo "Oracle Database instance $ORACLE_SID is down (PMON process is not running)."
    exit 1
fi

PATH=$ORACLE_HOME/perl/bin:$PATH
export PATH

# SQL query to get the edition
SQL_QUERY="SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
SELECT BANNER
FROM V\$VERSION
WHERE BANNER LIKE '%Edition%';"

# Execute the SQL query using sqlplus
EDITION=$(sqlplus -s  / as sysdba <<EOF
$SQL_QUERY
EXIT;
EOF
)


# SQL query to get the DATABASE_UNIQUENAME
SQL_QUERY="SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
SELECT DB_UNIQUE_NAME
FROM V\$DATABASE;"

# Execute the SQL query using sqlplus
DATABASE_UNIQUENAME=$(sqlplus -s  / as sysdba <<EOF
$SQL_QUERY
EXIT;
EOF
)


echo "####################################################################################"
echo "Path value with Perl exec path : $PATH"
echo "------------------------------------------------------------------------------------"
echo "You can now run Perf Tool Kit with this command : perl perf_tool_kit.pl  "
echo "------------------------------------------------------------------------------------"
echo "Oracle Connect String will be $CONNECT_STRING"
echo "=> change \$connect_string in $PERL_SCRIPT if you have to"
echo "Oracle Instance Name: $ORACLE_SID"
echo "Oracle Database Unique Name: $DATABASE_UNIQUENAME"
echo "Oracle Database Edition: $EDITION"
echo "####################################################################################"